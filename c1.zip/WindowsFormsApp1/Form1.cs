﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public int score1 = 0;
        public int score2 = 0;
        public bool Fup, Fdown, Sup, Sdown;
        public int speed = 15;
        public bool start = false;
        public int Mv = 1;
        public int Sv = 60;
        public int Lcounter = 1;
        public int numOfProfiles = 3;
        public int numOfGames =0;
        public Form1()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 1;
        }

        private void endToolStripMenuItem_Click(object sender, EventArgs e)
        {
            numOfGames++;
            Sg.SelectedIndex = 0;
            score1 = 0;
            score2 = 0;
            progressBar1.Value = 100;
            progressBar2.Value = 100;
            comboBox3.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;

        }

        private void currentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 2;
        }

        private void newToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 2;
        }

        private void statisticsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 4;
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 5;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            menuStrip1.BackColor = Color.Blue;
            panel3.BackColor = Color.Blue;
            label2.BackColor = Color.Blue;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            menuStrip1.BackColor = Color.Yellow;
            panel3.BackColor = Color.Yellow;
            label2.BackColor = Color.Yellow;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            menuStrip1.BackColor = Color.Green;
            panel3.BackColor = Color.Green;
            label2.BackColor = Color.Green;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Lcounter == 1)
            {
                button2.Visible = false;
            }
            else
            {
                button2.Visible = true;
                start = true;
                groupBox2.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            start = true;
            groupBox2.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            numOfGames++;
            Sg.SelectedIndex = 1;
            score1 = 0;
            score2 = 0;
            progressBar1.Value = 100;
            progressBar2.Value = 100;
            comboBox3.SelectedIndex = 1;
            comboBox2.SelectedIndex = 0;
            

        }

        private void button8_Click(object sender, EventArgs e)
        {
            numOfGames++;
            start = true;
            button8.Visible = false;

            if (start == false)
                button8.Visible = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.Text = " " + Mv + ":" + Sv;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (start == true)

            {

                int x = pictureBox4.Location.X;
                int y = pictureBox2.Location.Y;
                if (x >= 430)
                    x = 61;
                pictureBox4.Location = new Point(x + 5, y + 60);
            }


            if (pictureBox3.Bounds.IntersectsWith(pictureBox5.Bounds))
                timer1.Interval = 100;
            if (pictureBox3.Bounds.IntersectsWith(pictureBox6.Bounds))
                timer1.Interval = 10;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (start == true)
            {
                if (Fup == true && pictureBox2.Top >= 10)
                {
                    pictureBox2.Top -= speed;
                }
                if (Sup == true && pictureBox1.Top >= 10)
                {
                    pictureBox1.Top -= speed;
                }
                if (Fdown == true && pictureBox2.Top <= 245)
                {
                    pictureBox2.Top += speed;
                }
                if (Sdown == true && pictureBox1.Top <= 245)
                {
                    pictureBox1.Top += speed;
                }
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (start == true)
            {
                int x1 = pictureBox3.Location.X;
                int y1 = pictureBox1.Location.Y;
                if (x1 <= 90)
                    x1 = 412;
                pictureBox3.Location = new Point(x1 - 5, y1 + 60);
            }
            if (pictureBox4.Bounds.IntersectsWith(pictureBox5.Bounds))
                timer1.Interval = 100;
            if (pictureBox4.Bounds.IntersectsWith(pictureBox6.Bounds))
                timer1.Interval = 10;
        }

        private void timer4_Tick(object sender, EventArgs e)
        {

            if (start == true)
            {


                if (pictureBox3.Bounds.IntersectsWith(pictureBox2.Bounds))
                {
                    score1++;
                    progressBar1.Value = (progressBar1.Value - 20);
                    textBox2.Text = "" + textBox1.Text + " :" + score1 + " \n" + textBox1.Text + " :" + score2;
                }
                if (pictureBox4.Bounds.IntersectsWith(pictureBox1.Bounds))
                {
                    score2++;
                    textBox2.BackColor = Color.Red;
                    progressBar2.Value = (progressBar2.Value - 20);
                    textBox2.Text = "" + textBox1.Text + " :" + score1 + " \n" + textBox1.Text + " :" + score2;

                }
            }
        }

        private void timer5_Tick(object sender, EventArgs e)
        {
            if (start == true)
            {
                if (Lcounter >1)
                {
                    
                    pictureBox6.Visible = true;
                    pictureBox5.Visible = true;
                    int x1 = pictureBox5.Location.X;
                    int y1 = pictureBox5.Location.Y;
                    if (y1 >= 600)
                    {
                        y1 = 70;
                        pictureBox5.Location = new Point(x1, y1 + 20);
                    }
                    int x = pictureBox6.Location.X;
                    int y = pictureBox6.Location.Y;
                    if (y >= 600)
                    {
                        y = 70;
                        pictureBox6.Location = new Point(x, y + 10);
                    }
                }
                else
                {
                    pictureBox6.Visible = false;
                    pictureBox5.Visible = false;
                }
            }
        }

        private void timer6_Tick(object sender, EventArgs e)
        {
            if (start == true)
            {
                textBox6.Text = "Level  : " + Lcounter;
                timer6.Enabled = true;
                int a = Sv--;
                textBox3.Text = a.ToString();
                if (a == 1)
                {
                    Sv = 59;
                    Mv--;
                }


                if (Mv == 0 && Sv == 1 || progressBar2.Value == 0 || progressBar1.Value == 0)
                {
                    Lcounter++;
                    Mv = 1;
                    Sv = 60;
                    progressBar1.Value = 100;
                    progressBar2.Value = 100;
                    groupBox2.Visible = true;
                    start = false;
                }
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
            if (start == true)
                Visible = false;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox3.SelectedIndex;
            switch (index)
            {
                case 0:
                    {

                        textBox1.Text = "Sam";
                        radioButton2.Checked = true;
                        radioButton5.Checked = true;
                        textBox4.Text = "Shooter 2 : Sam";
                        comboBox2.Items.Remove(0);

                        break;
                    }
                case 1:
                    {

                        textBox1.Text = "Mike";
                        radioButton2.Checked = true;
                        radioButton5.Checked = true;
                        textBox4.Text = "Shooter 2 : Mike";
                        comboBox2.Items.Remove(1);
                        break;
                    }
                case 2:
                    {

                        textBox1.Text = "Joun";
                        radioButton2.Checked = true;
                        radioButton3.Checked = true;
                        textBox4.Text = "Shooter 2 : Joun";
                        comboBox2.Items.Remove(2);
                        break;
                    }

            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox2.SelectedIndex;
            switch (index)
            {
                case 0:
                    {

                        textBox1.Text = "Sam";
                        radioButton2.Checked = true;
                        radioButton5.Checked = true;
                        textBox5.Text = "Shooter 1 : Sam";
                        comboBox3.Items.Remove(0);

                        break;
                    }
                case 1:
                    {

                        textBox1.Text = "Mike";
                        radioButton2.Checked = true;
                        radioButton5.Checked = true;
                        textBox5.Text = "Shooter 1 : Mike";
                        comboBox2.Items.Remove(1);
                        break;
                    }
                case 2:
                    {

                        textBox1.Text = "Joun";
                        radioButton2.Checked = true;
                        radioButton3.Checked = true;
                        textBox5.Text = "Shooter 1 : Joun";
                        comboBox2.Items.Remove(2);
                        break;
                    }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void Sg_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W)
            {
                Fup = true;
            }
            if (e.KeyCode == Keys.Up)
            {
                Sup = true;
            }
            if (e.KeyCode == Keys.Down)
            {
                Sdown = true;
            }
            if (e.KeyCode == Keys.S)
            {
                Fdown = true;
            }
            if (e.KeyCode == Keys.Escape)
            {
                if (start == true)
                {

                    start = false;
                    groupBox2.Visible = true;
                }
                else
                {
                    start = true;
                    groupBox2.Visible = false;
                }

            }
            if (e.KeyCode == Keys.Space)
            {
                start = true;
            }
        }

        private void Sg_KeyUp(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.W)
            {
                Fup = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                Sup = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                Sdown = false;
            }
            if (e.KeyCode == Keys.S)
            {
                Fdown = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 0;
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 2;
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            numOfProfiles++;
            comboBox3.Items.Add(textBox1.Text);
            comboBox2.Items.Add(textBox1.Text);
            Sg.SelectedIndex = 1;
        }

        private void label18_Click(object sender, EventArgs e)
        {
            label18.Text = numOfGames.ToString();
        }

        private void label20_Click(object sender, EventArgs e)
        {
            label20.Text = numOfProfiles.ToString();
        }

        private void label8_Click(object sender, EventArgs e)
        {
        
        }

        private void label8_Click_1(object sender, EventArgs e)
        {
            if(score1>=score2)
            label18.Text = score1.ToString();

            if (score2 >= score1)
                label18.Text = score2.ToString();
        }

        private void label24_Click(object sender, EventArgs e)
        {
            if (score1 <= score2)
                label18.Text = score1.ToString();

            if (score2 <= score1)
                label18.Text = score2.ToString();
        }

        private void label24_Click_1(object sender, EventArgs e)
        {
            if (score1 >= score2)
                label24.Text = score1.ToString();

            if (score2 >= score1)
                label24.Text = score2.ToString();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (score1 < score2)
                label9.Text = score1.ToString();

            if (score2 < score1)
                label9.Text = score2.ToString();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Sg.SelectedIndex = 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            if (comboBox2.Text == "choose profile" || comboBox3.Text == "choose profile")

            {
                MessageBox.Show("choose profile");
            }
            else
            {
                start = false;
                Sg.SelectedIndex = 3;
            }
        }


    }
}
